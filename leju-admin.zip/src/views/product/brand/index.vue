<template>
  <div>
    brand
  </div>
</template>

<script>
export default {
  name: 'LejuAdminIndex',

  data() {
    return {

    }
  },

  mounted() {

  },

  methods: {

  }
}
</script>

<style scoped>

</style>
